package com.connectingDatabase;

import com.default_pages.WelcomePage;

public class Main {

    public static void main(String[] args) {
	// write your code herr
        WelcomePage wc = new WelcomePage();
        wc.setVisible(true);


    }
}
