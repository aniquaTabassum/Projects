package com.connectingDatabase;

import java.sql.*;

public class ConnectMSSQL {

    public ResultSet connectDB(String query, int type){
        ResultSet resultSet = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection connection = DriverManager
                    .getConnection(
                            "jdbc:sqlserver://localhost:1433;databaseName=COURIER_MANAGEMENT;selectMethod=cursor",   "sa", "123456");

            System.out.println("DATABASE NAME IS:"
                    + connection.getMetaData().getDatabaseProductName());
            if(type == 1) {
                Statement statement = connection.createStatement();
                resultSet = statement
                        .executeQuery(query);
            }
            else if(type == 2){
                Statement statement = connection.createStatement();
                statement
                        .executeUpdate(query);
            }
            else{
                Statement statement = connection.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                resultSet = ((PreparedStatement) statement).executeQuery();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultSet;
    }

}

