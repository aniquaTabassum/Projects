package com.Tables;

import javax.swing.table.AbstractTableModel;
import java.util.Vector;

public class MyTableModel extends AbstractTableModel {
        private Vector<String> columnNames;
        private  Vector<Vector<Object>> data;


        public MyTableModel(Vector<String> columnNames, Vector<Vector<Object>> data)
        {
            this.columnNames = columnNames;
            this.data = data;
        }
        public int getColumnCount() {
            return columnNames.size();
        }

        public int getRowCount() {
            return data.size();
        }

        public String getColumnName(int col) {
            return columnNames.get(col);
        }

        public Object getValueAt(int row, int col) {
            return data.get(row).get(col);
        }


        public boolean isCellEditable(int row, int col) {
            //Note that the data/cell address is constant,
            //no matter where the cell appears onscreen.

                return true;

        }

    public void  setValueAt (Object aValue, int row, int col){

        data.get(row).set(col, aValue);
        fireTableCellUpdated(row,col);

    }

}
