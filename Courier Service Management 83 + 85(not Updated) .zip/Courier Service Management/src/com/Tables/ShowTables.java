package com.Tables;
import com.connectingDatabase.ConnectMSSQL;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

/**
 * TableDemo is just like SimpleTableDemo, except that it uses a custom
 * TableModel.
 */
public class ShowTables extends JPanel {
    private boolean DEBUG = false;

    Vector<String> columnNames;
    Vector<Vector<Object>> data;
    String tableName;
    JFrame frame;
    JScrollPane scrollPane;
    String ascOrDesc = "ASC";
    ResultSet resultSet;
    JTable table;
    int selectedIndex;
    String query;
    ConnectMSSQL cm;
    int state  = 0;
    String selectedColumnForSorting;
    Vector<JLabel> vectorOfLabels;
    Vector<JTextField> vectorOfTextFields;
    int row = -1;
    public ShowTables(Vector<String> columnNames, Vector<Vector<Object>> data, String tableName, int selectedIndex) {
        super(new GridLayout(1, 0));

        this.data = data;
        this.columnNames = columnNames;
        this.tableName = tableName;
        this.selectedIndex = selectedIndex;
        initializeGUI();
        createTable();
        addActionListeners();
        setTheTitle();

    }
    private void setTheTitle()
    {
        JFrame topFrame = (JFrame) SwingUtilities.getWindowAncestor(scrollPane);
        topFrame.setTitle("Let's Send!");
    }


    private void initializeGUI()
    {
        frame = new JFrame();
        this.setLayout(new BorderLayout());
        fillUpFields();
    }

    private void fillUpFields()
    {
        createQuery();
        runQuery();
        /*try {
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = 0;

            columnCount = metaData.getColumnCount();

        }catch (SQLException e)
        {
            e.printStackTrace();
        }*/
        state+=1;

    }
    private void createTable()
    {
        table = new JTable(new MyTableModel(columnNames, data));
        table.setPreferredScrollableViewportSize(new Dimension(1080, 100));
        table.repaint();

        //Create the scroll pane and add the table to it.
        scrollPane = new JScrollPane(table);
        frame.setPreferredSize(new Dimension(1280,800));
        frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
        frame.add(scrollPane);
        frame.repaint();

        setOpaque(true);
        //frame.add(this);
        showDataInGUI();
        frame.pack();
        frame.setVisible(true);
    }
    private void addActionListeners()
    {

        table.getTableHeader().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("came here");

                    int column = table.columnAtPoint(e.getPoint());

                        sortAccordingToColumnName(column);


            }
        });
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                row = table.getSelectedRow();
                for(int i = 0; i<columnNames.size();i++)
                {
                    System.out.println(columnNames.get(i)+" "+data.get(row).get(i));
                }
                int column = table.getSelectedColumn();
                fillTextBoxes(row);

            }
        });

    }


    private void showDataInGUI()
    {
         vectorOfLabels = new Vector<JLabel>(columnNames.size());
         vectorOfTextFields = new Vector<JTextField>(columnNames.size());

        initialiseLabels();
        initializeTextFields(row);

        insertIntoGUI();
    }
    private void initialiseLabels()
    {
        for(int i = 0;i<columnNames.size();i++)
        {
            vectorOfLabels.add(new JLabel(columnNames.get(i)));
        }
    }
    private void initializeTextFields(int row)
    {
        for(int i = 0;i<columnNames.size();i++)
        {
            vectorOfTextFields.add(new JTextField());
            vectorOfTextFields.get(i).setPreferredSize(new Dimension(900,50));

        }
    }
    private void fillTextBoxes(int row)
    {
        for(int i=0;i<columnNames.size();i++) {
            if (row != -1)
            {
                String value = data.get(row).get(i).toString();
                if(value == null)
                {

                }
                else{
                       vectorOfTextFields.get(i).setText(value);
                }

                }
            }
    }

    private void insertIntoGUI()
    {
        for(int i=0;i<columnNames.size();i++)
        {
            JPanel tempPanel = new JPanel();
            vectorOfTextFields.get(i).setVisible(true);
            vectorOfLabels.get(i).setVisible(true);
            tempPanel.add(vectorOfLabels.get(i), FlowLayout.LEFT);
            tempPanel.add(vectorOfTextFields.get(i), BorderLayout.WEST);
            tempPanel.setVisible(true);
            frame.add(tempPanel);
            frame.repaint();
        }
    }
    private void sortAccordingToColumnName(int column)
    {
        setSelectedColumn(column);
        createQuery();
        runQuery();
        createNewTableData();

    }

    private void setSelectedColumn(int column)
    {
        selectedColumnForSorting = columnNames.get(column);
    }

    private void createQuery()
    {
        if(state == 0)
        {
            query = "SELECT *FROM "+tableName;
        }
        else {
            query = "SELECT *FROM "+tableName+" ORDER BY "+selectedColumnForSorting+" ASC";

        }

    }

    private void createSearchQuery(String q)
    {
        query = q;
    }
    private void runQuery()
    {
        cm = new ConnectMSSQL();
        resultSet = cm.connectDB(query,1);
    }

    private void createNewTableData()
    {
        columnNames = new Vector<String>();
        try {
        ResultSetMetaData metaData = resultSet.getMetaData();
        int columnCount = 0;

            columnCount = metaData.getColumnCount();
            for (int column = 1; column <= columnCount; column++) {
                columnNames.add(metaData.getColumnName(column));
            }

        data = new Vector<Vector<Object>>();
        while (resultSet.next()) {
            Vector<Object> vector = new Vector<Object>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(resultSet.getObject(columnIndex));
            }
            data.add(vector);
        }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //remove(scrollPane);
        updateTable();

    }

    private void updateTable()
    {
        AbstractTableModel model = (AbstractTableModel)table.getModel();

        for(int i = 0;i<data.size();i++)
        {
            for(int j=0;j<columnNames.size();j++)
            {
                model.setValueAt(data.get(i).get(j), i, j);
                System.out.println(data.get(i).get(j));
                table.repaint();

            }
        }
    }


    /**
     * Create the GUI and show it. For thread safety, this method should be
     * invoked from the event-dispatching thread.
     */
}